<?php

function ObtenerConexion() {
    return new PDO('mysql:host=localhost;dbname=tp__1_web_2;charset=utf8', 'root', '');
}

function ObtenerMarcas() {
    $db = ObtenerConexion();
    $query = $db->prepare('SELECT * FROM marca');
    $query->execute();
    
    return $query->fetchAll(PDO::FETCH_OBJ);
}

function ObtenerProductos() {
    $db = ObtenerConexion();
    $query = $db->prepare('SELECT * FROM productos');
    $query->execute();
    
    return $query->fetchAll(PDO::FETCH_OBJ);
}

function insertoMarcas($nombre, $importador, $paisorigen) {
    $db = ObtenerConexion();
    $query = $db->prepare('INSERT INTO marca(nombre_marca, importador, pais_origen) VALUES (?, ?, ?)');
    $query->execute([$nombre, $importador, $paisorigen]);

    return $db->lastInsertId();
}

function existeMarca($nombre_marca) {
    $db = ObtenerConexion();
    $query = $db->prepare("SELECT COUNT(*) FROM marca WHERE nombre_marca = :nombre_marca");
    $query->bindParam(':nombre_marca', $nombre_marca);
    $query->execute();

    return $query->fetchColumn() > 0;
}

function insertoProductos($marcaproducto, $tipoproducto, $modelo, $color, $descripcion) {
    $db = ObtenerConexion();
    $query = $db->prepare('INSERT INTO productos(marca_producto, tipo_producto, modelo, color, descripcion_producto) VALUES (?, ?, ?, ?, ?)');
    $query->execute([$marcaproducto, $tipoproducto, $modelo, $color, $descripcion]);

    return $db->lastInsertId();
}

function eliminarMarca($nombre_marca) {
    $db = ObtenerConexion();
    
    $queryProductos = $db->prepare("DELETE FROM productos WHERE marca_producto = ?");
    $queryProductos->execute([$nombre_marca]);

    $query = $db->prepare("DELETE FROM marca WHERE nombre_marca = ?");
    $query->execute([$nombre_marca]);
}

function eliminarProducto($id) {
    $db = ObtenerConexion();
    $query = $db->prepare("DELETE FROM productos WHERE id_productos = ?");
    $query->execute([$id]);
}

function obtenerProductosPorMarca($nombre_marca) {
    $db = ObtenerConexion();
    $query = $db->prepare("SELECT * FROM productos WHERE marca_producto = :nombre_marca");
    $query->bindParam(':nombre_marca', $nombre_marca);
    $query->execute();

    return $query->fetchAll(PDO::FETCH_OBJ);
}

function obtenerProductoPorId($id) {
    $db = ObtenerConexion();
    $query = $db->prepare("SELECT * FROM productos WHERE id_productos = ?");
    $query->execute([$id]);

    return $query->fetch(PDO::FETCH_OBJ); 
}

function obtenerIDmarca($id){
    $db = ObtenerConexion();
    $query = $db->prepare("SELECT * FROM marca WHERE id = ?");
    $query->execute([$id]);
    $idmarca = $query->fetch(PDO::FETCH_OBJ);
    return  $idmarca;
}

function cambioValoresMarca($id, $importador, $paisOrigen){
    $db = ObtenerConexion();
    $query = $db->prepare('UPDATE marca SET importador = ?, pais_origen = ? WHERE id = ?');
    $query->execute([$importador, $paisOrigen, $id]);
}

function obtenerIDproducto($id){
    $db = ObtenerConexion();
    $query = $db->prepare("SELECT * FROM productos WHERE id_productos = ?");
    $query->execute([$id]);
    $idproducto = $query->fetch(PDO::FETCH_OBJ);
    return  $idproducto;
}

function cambioValoresProducto($id,  $tipoproducto, $modelo, $color, $descripcion ){
    $db = ObtenerConexion();
    $query = $db->prepare('UPDATE productos SET tipo_producto = ?, modelo = ?, color = ?, descripcion_producto = ? WHERE id_productos = ?');
    $query->execute([$tipoproducto, $modelo, $color, $descripcion, $id]);
}

?>
