<?php
require_once "./app/db.php";

function mostrarProductos() {
    require_once "templates/header.php";
    require_once "templates/forms/form_agregarProd.php";

    $productos = ObtenerProductos();
    ?>

    <ul class="list-group">
        <?php foreach ($productos as $producto) { ?> 
            <li class="list-group-item marcas">
                <div>
                    <b><?php echo $producto->marca_producto . "|" . $producto->tipo_producto . "|" . $producto->modelo . "|" . $producto->color; ?></b>
                </div>
                <div class="actions">
                    <a href="producto/<?php echo $producto->id_productos; ?>" type="button" class="btn btn-primary ml-auto">Ver Producto</a>
                    <a href="formModificar-producto/<?php echo $producto->id_productos; ?>" type="button" class="btn btn-success ml-auto">Modificar</a> 
                    <a href="eliminar-prod/<?php echo $producto->id_productos; ?>" type="button" class="btn btn-danger ml-auto">Borrar</a>
                </div>
            </li>
        <?php } ?>
    </ul>

    <?php
    require_once "templates/footer.php";
}

function mostrarProducto($id) {
    require_once "templates/header.php";

    $producto = obtenerProductoPorId($id);
    ?>
    <div class="product-details">
        <h2>Detalles del Producto</h2>
        <p><strong>Marca:</strong> <?php echo($producto->marca_producto); ?></p>
        <p><strong>Tipo:</strong> <?php echo($producto->tipo_producto); ?></p>
        <p><strong>Modelo:</strong> <?php echo($producto->modelo); ?></p>
        <p><strong>Color:</strong> <?php echo($producto->color); ?></p>
        <p><strong>Descripción:</strong> <?php echo($producto->descripcion_producto); ?></p>
    </div>
    <?php
    echo "<div><a href='/TP_Web2/marcas' class='btn btn-success ml-2'>Regresar</a></div>";
    require_once "templates/footer.php";
}

function añadirProductos() {
    require_once "templates/header.php";

    $marcaproducto = $_POST['marca_producto'];
    $tipoproducto = $_POST['tipo_producto'];
    $modelo = $_POST['modelo'];
    $color = $_POST['color'];
    $descripcion = $_POST['descripcion'];

    $id = insertoProductos($marcaproducto, $tipoproducto, $modelo, $color, $descripcion);
    if ($id) {
        header('Location: /TP_Web2/productos');
    } else {
        echo "No se pudo insertar el producto correctamente.";
    }

    require_once "templates/footer.php";
}

function removerProducto($id) {
    eliminarProducto($id);
    header('Location: /TP_Web2/productos');
}

function mostrarFormModificarProducto($id) {
    require_once "templates/header.php";
    $idproducto = obtenerIDproducto($id);
    require_once "templates/forms/form_modificarProd.php";
    require_once "templates/footer.php";
}

function modificarProducto() {
    $id = $_POST['idproducto'];
    $tipoproducto = $_POST['tipo-productoNuevo'];
    $modelo = $_POST['modeloNuevo'];
    $color = $_POST['colorNuevo'];
    $descripcion = $_POST['descripcionNueva'];

    cambioValoresProducto($id, $tipoproducto, $modelo, $color, $descripcion);
    header('Location: /TP_Web2/productos');
}
?>
