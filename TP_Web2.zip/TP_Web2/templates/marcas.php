<?php
require_once "./app/db.php";

function mostrarMarcas() {
    require_once "templates/header.php";
    require_once "templates/forms/form_agregar.php";

    $marcas = ObtenerMarcas();
    ?>

    <ul class="list-group">
        <?php foreach ($marcas as $marca) { ?> 
            <li class="list-group-item marcas">
                <div>
                    <b><?php echo $marca->nombre_marca . "|" . $marca->importador . "|" . $marca->pais_origen; ?></b>
                </div>
                <div class="actions">
                    <a href="productos-marca/<?php echo urlencode($marca->nombre_marca); ?>" type="button" class="btn btn-primary ml-auto">Ver Productos</a>
                    <a href="formModificar-marca/<?php echo $marca->id; ?>" type="button" class="btn btn-success ml-auto">Modificar</a> 
                    <a href="eliminar/<?php echo $marca->nombre_marca; ?>" type="button" class="btn btn-danger ml-auto">Borrar</a>
                </div>
            </li>
        <?php } ?>
    </ul>

    <?php
    require_once "templates/footer.php";
}

function añadirMarcas() {
    require_once "templates/header.php";

    $nombre = $_POST['nombre'];
    $importador = $_POST['importador'];
    $paisorigen = $_POST['pais_origen'];

    if (existeMarca($nombre)) {
        echo "
            <div class='alert alert-danger'>
                Error: La marca '$nombre' ya existe. No se puede agregar una marca duplicada.
                <a href='marcas' class='btn btn-success ml-2'>Regresar</a>
            </div>
        ";
    } else {
        $id = insertoMarcas($nombre, $importador, $paisorigen);

        if ($id) {
            header('Location: /TP_Web2/marcas');
        } else {
            echo "
                <div class='alert alert-danger'>
                    Error: No se pudo insertar la nueva marca correctamente.
                    <a href='/TP_Web2/form_agregar' class='btn btn-primary ml-2'>Regresar</a>
                </div>
            ";
        }
    }

    require_once "templates/footer.php";
}

function removerMarca($nombre_marca) {
    eliminarMarca($nombre_marca);
    header('Location: /TP_Web2/marcas');
}

function productosPorMarca($nombre_marca) {
    require_once "templates/header.php";

    $productos = obtenerProductosPorMarca($nombre_marca);

    echo "<h2>Productos de la marca: $nombre_marca</h2>";

    if (!empty($productos)) {
        echo "<ul class='list-group'>";
        foreach ($productos as $producto) {
            echo "
                <li class='list-group-item'>
                    <b>{$producto->marca_producto}</b> | {$producto->tipo_producto} | {$producto->modelo} | {$producto->color}
                </li>";
        }
        echo "<div><a href='/TP_Web2/marcas' class='btn btn-success ml-2'>Regresar</a></div>";
        echo "</ul>";
    } else {
        echo "<div class='alert alert-info'>No hay productos disponibles para esta marca.
            <a href='/TP_Web2/marcas' class='btn btn-success ml-2'>Regresar</a>
        </div>";
    }

    require_once "templates/footer.php";
}

function mostrarFormModificarMarca($id) {
    require_once "templates/header.php";
    $idmarca = obtenerIDmarca($id);
    require_once "templates/forms/form_modificarMarca.php";
    require_once "templates/footer.php";
}

function modificarMarca() {
    $id = $_POST['idmarca'];
    $importador = $_POST['importador-nuevo'];
    $paisOrigen = $_POST['pais_origen-nuevo'];

    cambioValoresMarca($id, $importador, $paisOrigen);
    header('Location: /TP_Web2/marcas');
}
?>
