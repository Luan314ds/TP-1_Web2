<main>
    <?php echo "<h2> Marca: $idmarca->nombre_marca </h2>"; ?>
    <form action="/TP_Web2/modificar-marca" method="POST" class="my-4" id="formulario">

        <input type="hidden" name="idmarca" value="<?= $idmarca->id ?>">
        <div class="row">  
            <div class="col-9">
                <div class="form-group">
                    <label>Importador</label>
                    <input required name="importador-nuevo" type="text" class="form-control" id="importador" value="<?= $idmarca->importador ?>">
                </div>
            </div>

            <div class="col-9">
                <div class="form-group">
                    <label>País de origen</label>
                    <input required name="pais_origen-nuevo" type="text" class="form-control" id="pais_origen" value="<?= $idmarca->pais_origen ?>">
                </div>
            </div>

            <button type="submit" class="btn btn-success mt-2">Modificar</button>
        </div>
    </form>
</main>
