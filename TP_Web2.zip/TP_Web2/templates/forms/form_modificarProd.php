<main>
    <?php echo "<h2> Marca: $idproducto->marca_producto </h2>"; ?>
    <form action="/TP_Web2/modificar-producto" method="POST" class="my-4" id="formulario">

        <input type="hidden" name="idproducto" value="<?= $idproducto->id_productos ?>">
        <div class="row">  
            <div class="col-9">
                <div class="form-group">
                    <label>Tipo de Producto</label>
                    <input required name="tipo-productoNuevo" type="text" class="form-control" id="tipo-productoNuevo" value="<?= $idproducto->tipo_producto ?>">
                </div>
            </div>

            <div class="col-9">
                <div class="form-group">
                    <label>Modelo del Producto</label>
                    <input required name="modeloNuevo" type="text" class="form-control" id="modeloNuevo" value="<?= $idproducto->modelo ?>">
                </div>
            </div>

            <div class="col-9">
                <div class="form-group">
                    <label>Color del Producto</label>
                    <input required name="colorNuevo" type="text" class="form-control" id="colorNuevo" value="<?= $idproducto->color ?>">
                </div>
            </div>

            <div class="col-9">
                <div class="form-group">
                    <label>Descripción del Producto</label>
                    <input required name="descripcionNueva" type="text" class="form-control" id="descripcionNueva" value="<?= $idproducto->descripcion_producto ?>">
                </div>
            </div>

            <button type="submit" class="btn btn-success mt-2">Modificar</button>
        </div>
    </form>
</main>
