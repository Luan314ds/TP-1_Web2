<main>
    <form action="agregar-prod" method="POST" class="my-4" id="formulario">
        <div class="row">
            <div class="col-9">
                <div class="form-group">
                    <label>Marca del Producto</label>
                    <select required name="marca_producto" class="form-control" id="marca_producto">
                        <option value="">Seleccione una marca</option>
                        <?php
                        $marcas = ObtenerMarcas();
                        foreach ($marcas as $marca) {
                            echo "<option value='{$marca->nombre_marca}'>{$marca->nombre_marca}</option>";
                        }
                        ?>
                    </select>
                </div>
            </div>

            <div class="col-9">
                <div class="form-group">
                    <label>Tipo de Producto</label>
                    <input required name="tipo_producto" type="text" class="form-control" id="tipo_producto">
                </div>
            </div>

            <div class="col-9">
                <div class="form-group">
                    <label>Modelo del Producto</label>
                    <input required name="modelo" type="text" class="form-control" id="modelo">
                </div>
            </div>

            <div class="col-9">
                <div class="form-group">
                    <label>Color del Producto</label>
                    <input required name="color" type="text" class="form-control" id="color">
                </div>
            </div>

            <div class="col-9">
                <div class="form-group">
                    <label>Descripción del Producto</label>
                    <input required name="descripcion" type="text" class="form-control" id="descripcion">
                </div>
            </div>
        </div>
        <button type="submit" class="btn btn-primary mt-2" id="boton-guardar">Guardar</button>
    </form>
</main>

<script src="js/mayProductos.js"></script>
